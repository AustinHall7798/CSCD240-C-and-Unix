#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int listCount(struct node *head);
void reverseList(struct node** head_ref);
void deleteElement(struct node **currP, char *value);
void listAllDelete(struct node **currP);
void insertElement(struct node **currP, char*value);
void sortLinkedList(struct node** currP);
void swapData(struct node* nOne, struct node* nTwo);
