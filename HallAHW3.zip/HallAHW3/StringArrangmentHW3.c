#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void sortString(char *s[], int count);

int main(){

        int i = 0;
        char buff[BUFSIZ];

        int count;
        char** s= malloc(sizeof(char*));

        printf("Here is the list of unsorted names: \n\n");

        for (count = 0; fgets(buff, sizeof(buff), stdin); count++){
		s[count] = malloc(strlen(buff) + 1);
		for(int k = 0; k < sizeof(buff); k++) {
			*(*(s+i)+k) = buff[k];
                }
		s = realloc(s, sizeof(char*)*(count+2));
		i++;
        }


        printf("\nCount is %d\n\n", count);

       sortString(s, count);

	printf("Here is the list of sorted names: \n\n");
	for(i = 0; i < count; i++) {
		printf("%s", s[i]);
	}
	free(s);
        return 0;
}

void sortString(char *s[], int count){
	char *temp = NULL;
     for(int i = 0; i < count - 1; i++) {
        for(int j = 0; j < count - 1; j++) {
            if(strcmp(s[j], s[j + 1]) > 0) {
		temp = s[j];
		s[j] = s[j+1];
		s[j+1] = temp;
            }
        }
     }
}

