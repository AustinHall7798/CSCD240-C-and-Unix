#include <stdio.h>
#include <stdlib.h>
#include <math.h>


void swapElements(int *a, int *b);
void sortArray (int *array, const int size);
void changeElements(int *val);
void printArray(int *array, const int size);
double findMean(int *array, const int size);
double findMedian(int *array, const int size);
double findStandardDeviation(int *array, const int size, double average);
void displayResults(int *ptr, const int size);

int main()
{
int n = 0;
int data;
int *ptr = malloc(sizeof(int));
//I need this printPtr so that the printed numbers won 't be out of order
int *printPtr = malloc(sizeof(int));
int i = 0;
int j = 0;

printf("Bonus version of the program. This program can read as many integers as the user types and keep on displaying the cumulative mean, median, and average of the numbers typed so far. Lastly, the allocated memory needs to be freed\nPlease type as many integers as you would like to:\n");
printf("Typing the number: \n");
for (;;) {
	int res = scanf("%d[^\n]", &data);
	if (res == EOF) break;
	ptr[i++] = data;
	printPtr[j++] = data;
	ptr = realloc(ptr, (i + 1) * sizeof(int));
	printPtr = realloc(printPtr, (j + 1) * sizeof(int));
	n++;
	printf("\n");
	printf("Displaying the numbers typed so far: \n");
	printArray(printPtr, n);
	displayResults(ptr, n);
	printf("Typing the number:\n");
	}
free(ptr);
free(printPtr);
}

void displayResults(int *ptr, const int n)
{
	printf("\nMean of the numbers is: ");
	double x = findMean(ptr, n);
	printf("%f\n", x);
	printf("Median of the numbers is: ");
	double y = findMedian(ptr, n);
	printf("%f\n", y);
	printf("Standard Deviation of the numbers is: ");
	double z = findStandardDeviation(ptr, n, x);
	printf("%f\n", z);
}

void swapElements(int *x, int *y)
{
	int temp = *x;
	*x = *y;
	*y = temp;
}

void sortArray(int *array, const int size)
{
	for (int i = 0; i < size; i++) {
		for (int j = i + 1; j < size; j++) {
			if (array[j] < array[i]) {
				swapElements(&array[j], &array[i]);
			}
		}
	}
}

void printArray(int *array, const int size)
{
	for (int i = 0; i < size; i++) {
		printf("%d, ", array[i]);
	}
}

double findMean(int *array, const int size)
{

	if (size == 0) return 0;
	double x = 0;
	for (int i = 0; i < size; i++) {
		x += array[i];
	}
	return x / size;
}

double findMedian(int *array, const int size)
{

	sortArray(array, size);
	if (size % 2 == 1) {
		int x = size / 2;
		return array[x];
	} else {
		int y = size / 2;
		int z = y - 1;
		return ((array[y] + array[z]) / 2);
	}
}

double findStandardDeviation(int *array, const int size, double average)
{
	double standardDeviation = 0;
	if (size == 1)
		return standardDeviation;
	for (int i = 0; i < size; ++i)
		standardDeviation += pow(array[i] - average, 2);
	return sqrt(standardDeviation / (size - 1));
}
