#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void swapElements(int *a, int *b);
void sortArray(int *array, const int size);
void changeElements(int *val);
void printArray(int *array, const int size);
double findMean(int *array, const int size);
double findMedian(int *array, const int size);
double findStandardDeviation( int *array, const int size, double average);

int main(){

	int  n, *x;
        double mean = 0.0, median = 0.0, stdDev = 0.0;

	printf("This is the basic part of the program that asks the user to type the number of integers, i.e., 'n'. Next, allocate memory for 'n' integers, read the values of 'n' integers into the allocated memory usining scanf; next, find the mean, median and average of 'n' integers.Lastly, the allocated memory needs to be freed.\n");
        
	printf("\nRead using scanf how many integers you would like to type:\n");
        scanf("%d", &n);

        
	/*****************************************************************/

	//x is not automatically assigned a memory block when it is defined as a pointer variable, you need to allocate a block
	//of memory large enough to hold 'n' integers
        // Write the function that allocates memory to hold 'n' integers

        x = malloc(sizeof(int) * n);
        printf("Please type 'n' integers: \n");
	/***********************************************************************/ 
	//Read in the list of numbers 'n' into the allocated block using scanf 
        int i = 0;
        while(i < n) {
        scanf("%d[^\n]", &x[i++]);
        }
		
  
        printf("Displaying the numbers:\n");

        printArray(x, n);      
 
        mean = findMean(x, n);
        printf("Mean of the numbers is: %f\n", mean);

        median = findMedian(x, n);
        printf("Median of the numbers is: %f\n", median);
        
        stdDev = findStandardDeviation(x, n, mean);
        printf("Standard deviation of the numbers is: %f\n", stdDev);
	
        free(x);
        
        
        
        return 0;
}





void printArray( int *array, const int size){

     for (int i = 0; i < size; i++) {
                printf("%d ", array[i]);
        }
	printf("\n");
}

void sortArray(int *array, const int size){

     for (int i = 0; i < size; i++) {
                for (int j = i + 1; j < size; j++) {
                        if (array[j] < array[i]) {
                                swapElements(&array[j], &array[i]);
                        }
                }
        }
}

void swapElements( int *x, int *y){

     int temp = *x;
        *x = *y;
        *y = temp;

}



double findMean(int *array, const int size){

    if (size == 0) return 0;
        double x = 0;
        for (int i = 0; i < size; i++) {
                x += array[i];
        }
        return x / size;
}

double findMedian(int *array, const int size){

    sortArray(array, size);
        if (size % 2 == 1) {
                int x = size / 2;
                return array[x];
        } else {
                int y = size / 2;
                int z = y - 1;
                return ((array[y] + array[z]) / 2);
        }
}


double findStandardDeviation( int *array, const int size, double average){

       double standardDeviation = 0;
        if (size == 1)
                return standardDeviation;
        for (int i = 0; i < size; ++i)
                standardDeviation += pow(array[i] - average, 2);
        return sqrt(standardDeviation / (size - 1));

}
