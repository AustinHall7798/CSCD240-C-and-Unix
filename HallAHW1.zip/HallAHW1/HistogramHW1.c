#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#define MAXROWS 100
#define NUM_ALPHABETS 26

int main(){


        char sentence[MAXROWS] = {0};
        char alphabets[] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        int frequency[NUM_ALPHABETS] = {0};
        int i,j;

        fgets(sentence,sizeof(sentence),stdin);
        sentence[strlen(sentence)-1] = '\0';

        for (i = 0; i < strlen(sentence); i++)
        {
         for(j=0;j<26;j++)
         {
              if (toupper(sentence[i]) == alphabets[j])
              {
                   frequency[j]++;
              }
         }
        }
        printf("Alphabets\tFrequency\tHistogram\n\n");

        for(j=0;j<26;j++)
        {
          printf("    %c",'A'+j);
          printf("\t\t    %d\t\t    ", frequency[j]);
                for(int k=0; k < frequency[j]; k++) 
                {
                printf("*");
                }
          printf("\n");
    }



    return 0;
}
