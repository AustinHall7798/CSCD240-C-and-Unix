#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "fileTest.h"

int countString(const char *fileName, char *str)
{
    for (int i = 0; str[i]; i++)
        {
            str[i] = tolower(str[i]);
        }

    int word_count = 0;
    FILE *buf = fopen(fileName, "r");

    char contents[BUFSIZ];

    while (fgets(contents, BUFSIZ, buf) != NULL)
    {
        int index = 0;
        char *position;
        for (int i = 0; contents[i]; i++)
        {
            contents[i] = tolower(contents[i]);
        }
        while ((position = strstr(contents + index, str)) != NULL)
        {
            index = (position - contents) + 1;

            word_count++;
        }
    }
    fclose(buf);
    return word_count;
}

int countEmptyLines(const char *fileName)
{

    int emptyLine = 0;

    FILE *buf = fopen(fileName, "r");

    char contents[BUFSIZ];

    while (fgets(contents, BUFSIZ, buf) != NULL)
    {
        if (strcmp(contents, "\n") == 0)
        {
            emptyLine++;
        }
    }
    fclose(buf);
    return emptyLine;
}
