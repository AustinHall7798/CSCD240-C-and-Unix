int countString(const char *fileName, char *str);
int countEmptyLines(const char *fileName);