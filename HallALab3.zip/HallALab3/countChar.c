#include <stdio.h>
#include <ctype.h>
#define MAXSIZE 100

int main()
{
	char ch;
	int i;
	char sentence[MAXSIZE];
	int alphabetsCount = 0;
	printf("Type a sentence: \n");
	
	fgets(sentence, MAXSIZE, stdin);

	for (i = 0; sentence[i] != 0; i++ )
	{
    		sentence[i] = tolower( sentence[i] );
	}

	printf("Type a character that you'd like to find the number of occurrences in a sentence:\n");

	while((ch = getchar()) == '\n');
	
	ch = tolower(ch);

	i = 0;
	while(sentence[i] != '\0')
	{
		if(sentence[i] == ch) {
			alphabetsCount++;
	}
		i++;
	}
        
	printf("Alphabet %c has a frequency of %d\n", ch, alphabetsCount);
	return 0;
 }
