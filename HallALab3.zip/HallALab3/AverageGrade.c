#include <stdio.h>
int main() 
{ 
int i = 0; 
int grade; 
double sum = 0.0;
double average =0.0;

scanf("%d", &grade);

printf("Please input 10 grades :\n");

while(grade != -1000) { 

	sum+= grade;
	i++;

	average = sum / i;
	printf("sum is: %f\n", sum);
	printf("Average is: %f\n", average);
	scanf("%d", &grade);	

       } 

return 0;
 } 
