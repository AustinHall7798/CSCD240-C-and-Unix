#include <stdio.h>

int main() 
{

printf("%lu\n", sizeof(short));
printf("%lu\n", sizeof(int));
printf("%lu\n", sizeof(char));
printf("%lu\n", sizeof(double));
printf("%lu\n", sizeof(long));
printf("%lu\n", sizeof(long double));
printf("%d\n", sizeof(short) < sizeof(int));
printf("%d\n", sizeof(char) < sizeof(short));
printf("%d\n", sizeof(long) > sizeof(int)); 
printf("%d\n", sizeof(long double) > sizeof(double));

return 0;
}
